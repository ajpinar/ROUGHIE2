UM7_BIN_v2
==========

Reads euler angles and GPS data using binary packet
